<?php
$file="./fleData.txt";
$data=fopen("$file","a");
fwrite($data,"what's going on");

?>